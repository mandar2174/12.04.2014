package com.aricent.data.generation;

public class DataGenerationConstant {
	public static final String GROLOCATIONURL = "http://maps.googleapis.com/maps/api/directions/json";
	public static final String QUESTIONMARK = "?";
	public static final String EQUAL = "=";
	public static final String ORIGIN = "origin=";
	public static final String DESTINATION = "destination=";
	public static final String AMPERSEND = "&";
	public static final String LATITUDE="lat";
	public static final String LONGITUDE="lng";
	public static final String FILE_PATH="/home/filename.txt";

}
