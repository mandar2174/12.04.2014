package com.aricent.data.generation;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


/**
 * Class for changing the properties file
 * @author BGH33503
 *
 */
public class WritePropertiesFile {
	
	public static String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		System.out.println("FileName:" + fileName);
		this.fileName = fileName;
	}

	
	/**
	 * Function to set the property value
	 * 
	 * @param key
	 *            key to be used for changing the value
	 * @param value
	 *            value need to updated
	 */
	public static void setPropertyValue(String key, String value) {
			try {
			String inputFileName = fileName.replace("\\","/").replace("\n","").replace("\t","");
			FileInputStream in = new FileInputStream(inputFileName);
			Properties props = new Properties();
			props.load(in);
			in.close();
			FileOutputStream out = new FileOutputStream(inputFileName);
			
			props.setProperty(key, value);
			props.store(out, null);
			out.close();
		} catch (IOException e) {
		}
	}

}
