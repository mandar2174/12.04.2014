package com.aricent.data.generation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class DataUtility {

	public static int writeDataToFile(Object object) {
		try {
			File file = new File(DataGenerationConstant.FILE_PATH);

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write((String)object);
			bw.close();

			System.out.println("File writing Done");

		} catch (IOException e) {
		
		}
		return 1;
	}
}
