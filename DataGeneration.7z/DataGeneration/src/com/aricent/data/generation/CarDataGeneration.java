package com.aricent.data.generation;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CarDataGeneration {
	private static List<Double> latitude = new LinkedList<>();
	private static List<Double> longitude = new LinkedList<>();

	public static void main(String[] args) {
		HttpClient httpClient = new DefaultHttpClient();
		Map<Double, Double> locationCordinates = new HashMap<>();

		String source = "Kadubeesanahalli";
		String destination = "HSRLayout";
		try {
			// form the url for getting the location
			StringBuilder url = new StringBuilder();
			url.append(DataGenerationConstant.GROLOCATIONURL);
			url.append(DataGenerationConstant.QUESTIONMARK);
			url.append(DataGenerationConstant.ORIGIN);
			url.append(source);
			url.append(DataGenerationConstant.AMPERSEND);
			url.append(DataGenerationConstant.DESTINATION);
			url.append(destination);

			// give the url in the HTTPGET
			HttpGet httpGetRequest = new HttpGet(url.toString());

			// Execute HTTP request
			HttpResponse httpResponse = httpClient.execute(httpGetRequest);

			System.out.println("----------------------------------------");
			System.out.println(httpResponse.getStatusLine());
			System.out.println("----------------------------------------");

			// Get hold of the response entity
			HttpEntity entity = httpResponse.getEntity();

			// If the response does not enclose an entity, there is no need
			// to bother about connection release
			byte[] buffer = new byte[1024];
			if (entity != null) {
				InputStream inputStream = entity.getContent();
				try {
					int bytesRead = 0;
					/*
					 * BufferedInputStream bis = new BufferedInputStream(
					 * inputStream); while ((bytesRead = bis.read(buffer)) !=
					 * -1) { String chunk = new String(buffer, 0, bytesRead);
					 * System.out.println(chunk); }
					 */
					JSONObject jsonObject = new JSONObject(
							EntityUtils.toString(entity));
					processLocation(jsonObject);

				} catch (IOException ioException) {
					// In case of an IOException the connection will be released
					// back to the connection manager automatically
					ioException.printStackTrace();
				} catch (RuntimeException runtimeException) {
					// In case of an unexpected exception you may want to abort
					// the HTTP request in order to shut down the underlying
					// connection immediately.
					httpGetRequest.abort();
					runtimeException.printStackTrace();
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					// Closing the input stream will trigger connection release
					try {
						inputStream.close();
					} catch (Exception ignore) {
					}
				}
			}
		} catch (ClientProtocolException e) {
			// thrown by httpClient.execute(httpGetRequest)
			e.printStackTrace();
		} catch (IOException e) {
			// thrown by entity.getContent();
			e.printStackTrace();
		} finally {
			// When HttpClient instance is no longer needed,
			// shut down the connection manager to ensure
			// immediate deallocation of all system resources
			httpClient.getConnectionManager().shutdown();
		}

		
	}

	/**
	 * Function to process the location response
	 * 
	 * @param response
	 *            location response from the google api
	 */
	public static void processLocation(JSONObject jsonObject) {
		try {
			//JSONObject jsonObject = new JSONObject(response);
			if (null != jsonObject && jsonObject.has("routes")) {
				JSONArray jsonArray = jsonObject.getJSONArray("routes");
				if (jsonArray.length() > 0) {
					JSONObject jsonInnerObject = jsonArray.getJSONObject(0);
					if (jsonInnerObject.has("legs")) {
						JSONArray legsJSONArray = jsonInnerObject
								.getJSONArray("legs");
						for (int index = 0; index < legsJSONArray.length(); index++) {
							JSONObject legsJsonObject = legsJSONArray
									.getJSONObject(index);
							if (legsJsonObject.has("steps")) {
								JSONArray stepsJSONArray = legsJsonObject
										.getJSONArray("steps");
								for (int indexStep = 0; indexStep < stepsJSONArray
										.length(); indexStep++) {
									JSONObject stepsJSONObject = stepsJSONArray
											.getJSONObject(indexStep);

									if (stepsJSONObject.has("end_location")) {
										latitude.add(stepsJSONObject
												.getJSONObject("end_location")
												.getDouble(
														(DataGenerationConstant.LATITUDE)));
										longitude
												.add(stepsJSONObject
														.getJSONObject(
																"end_location")
														.getDouble(
																(DataGenerationConstant.LONGITUDE)));

									}
									if (stepsJSONObject.has("start_location")) {
										latitude.add(stepsJSONObject
												.getJSONObject("start_location")
												.getDouble(
														(DataGenerationConstant.LATITUDE)));
										longitude
												.add(stepsJSONObject
														.getJSONObject(
																"start_location")
														.getDouble(
																(DataGenerationConstant.LONGITUDE)));

									}
								}

							}
						}
					}

				}
			}
		} catch (JSONException e) {

		}
		System.out.println("Latitude: ");
		for (Double lat : latitude) {
			System.out.println(lat);
		}

		System.out.println("Longitude : ");
		for (Double lon : longitude) {
			System.out.println(lon);
		}

	}
}
