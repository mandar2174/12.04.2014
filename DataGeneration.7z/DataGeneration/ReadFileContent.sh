#!/bin/bash
filecontent=( `cat $1 `)

for t in "${filecontent[@]}"
do
echo $t
done
echo "Read file content!"
